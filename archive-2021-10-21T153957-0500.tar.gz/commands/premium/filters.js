const Discord = require('discord.js');

module.exports = {
    name: "filter",
    category: "Music",
    description: "Sets a filter for the song",
    premium: true,
    timeout: 3000,
    usage: "[command]",
    async execute(message, args) {
      const client = message.client;
      let filter = args[0];
      if (!filter) return message.reply("Please provide a filter!")
        if(!message.member.voice.channel) 
        return message.reply('Please join a voice channel!');
        await client.distube.setFilter(message, filter)
        await message.react('✅');
    }
}
