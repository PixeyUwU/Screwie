const Discord = require("discord.js");
const db = require('quick.db');

module.exports = {
	name: "setpremium",
    description: "Sets premium to a user",
    cooldown: 5,
    async execute(message, args) {
    	const user = message.mentions.users.first();
        if (message.author.id === "809420610186772541" || message.author.id === "804777320123990108") {
            if (!user) return message.reply("please provide a user!")
        const stat = db.get(`user_premium_${user.id}`);
        if (!stat) {
        	db.set(`user_premium_${user.id}`, 'true')
        } else {
        	if (stat === "true") {
            	db.set(`user_premium_${user.id}`, 'false')
                const embed = new Discord.MessageEmbed()
                    .setTitle(`\`✅\` ${user.username} has been removed from premium.`)
                    .setAuthor(`${message.author.username}`, message.author.avatarURL())
                    .setDescription(`This user will no longer have access to Axdroid's premium commands.\n\nPremium taken from user by ${message.author}`)
                    .setTimestamp()
                message.channel.send(embed)
            } else if (stat === "false") {
            	db.set(`user_premium_${user.id}`, 'true')
                const embed = new Discord.MessageEmbed()
                    .setTitle(`\`✅\` ${user.username} has been given premium! 🥳🥳`)
                    .setAuthor(`${message.author.username}`, message.author.avatarURL())
                    .setDescription(`This user will now have access to Axdroid's premium commands.\n\nPremium given to user by ${message.author}`)
                    .setTimestamp()
                message.channel.send(embed)
            } else {
            	return message.reply(`an error occured because the database value was not correct. Value found: \`${stat}\``)
            }
        }
      
        } else {
            return message.reply("why tf you tryna use premium")
        }
    }
}