const Discord = require('discord.js');

module.exports = {
	name: "stop",
    description: "Makes the bot leave a VC (voice channel)",
    guildOnly: true,
    execute(message, args) {
    	const client = message.client;
        try {
			if (!message.member.voice.channel) return message.reply("You are not in a voice channel!")
			client.distube.stop(message);
			const embed = new Discord.MessageEmbed()
			.setTitle(`\`🎶\` I have left the voice channel`)
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
        } catch (err) {
			console.log(err);
		}
    }
}