const Discord = require('discord.js');

module.exports = {
	name: "shuffle",
    description: "Shuffles the queue",
    guildOnly: true,
    execute(message, args) {
    	const client = message.client;
        if (!message.member.voice.channel) return message.reply("You are not in a voice channel!")
		
		client.distube.shuffle(message);
		const embed = new Discord.MessageEmbed()
			.setTitle(`\`🔀\` The queue has been shuffled`)
        	.setColor('5124e3')
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
    }
}