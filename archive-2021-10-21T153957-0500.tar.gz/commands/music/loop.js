const Discord = require('discord.js');

module.exports = {
	name: "loop",
    description: "Loops the current song",
    guildOnly: true,
    usage: "<repeat-mode (0 to disable looping-- any other number to enable it) >",
    execute(message, args) {
    	const client = message.client;
        if (!message.member.voice.channel) return message.reply("You are not in a voice channel!")

		client.distube.setRepeatMode(message, parseInt[args[0]])
		if (args[0] === "0") {
			const embed = new Discord.MessageEmbed()
			.setTitle(`\`🔂 - ❌\` I stopped looping the current song`)
        	.setColor('5124e3')
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
		} else {
			const embed = new Discord.MessageEmbed()
			.setTitle(`\`🔂\` I am now looping the current song`)
        	.setColor('5124e3')
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
    }
    }
}