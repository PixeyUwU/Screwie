const Discord = require('discord.js');

module.exports = {
	name: "queue",
    description: "Shows the current queue in a server",
    guildOnly: true,
    execute(message, args) {
    	const client = message.client;
        if (!message.member.voice.channel) return message.reply("*You are not in a voice channel!")

		try {
			const queue = client.distube.getQueue(message);
            const embed = new Discord.MessageEmbed()
			.setTitle(`\`🎶\` **My queue**`)
        	.setColor('5124e3')
            .setDescription(`${queue.songs.map((song, id) => `**\`${id + 1}:\`** **${song.name}** - \`${song.formattedDuration}\``).slice(0, 10).join('\n')}`)
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
		} catch (err) {
			console.log(err);
		}
    }
}