const Discord = require('discord.js');

module.exports = {
	name: "skip",
    description: "Skips to the next song in the queue",
    guildOnly: true,
    execute(message, args) {
    	const client = message.client;
        try {
			if (!message.member.voice.channel) return message.reply("You are not in a voice channel!")
		client.distube.skip(message);
        const embed = new Discord.MessageEmbed()
			.setTitle(`\`🎶\` I skipped the current song`)
        	.setColor('5124e3')
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
        } catch (err) {
			console.log(err);
		}
    }
}