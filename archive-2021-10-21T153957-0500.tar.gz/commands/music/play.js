const Discord = require('discord.js');

module.exports = {
	name: "play",
    description: "Lets you play music!",
    usage: "<song>",
    guildOnly: true,
    execute(message, args) {
    	const client = message.client;
        if (!message.member.voice.channel) return message.reply("You aren't in a voice channel!")
        const music = args.join(" ");
        if (!music) return message.reply("**please provide a song to play!**")
        const embed = new Discord.MessageEmbed()
			.setDescription(`\`🎶\` Your music will begin in a moment`)
    	message.channel.send(embed)
        client.distube.play(message, music);
    }
}