const Discord = require('discord.js');

module.exports = {
	name: "setvolume",
    description: "Sets the volume of the music",
    guildOnly: true,
    usage: "<vol>",
    execute(message, args) {
    	const client = message.client;
        if (!message.member.voice.channel) return message.reply("You are not in a voice channel!")
		
		if (!args[0]) return message.reply("Please provide a volume!")
		if (args[0] > 200) return message.reply("The volume can't go over 200%!")
		if (args[0] < 0) return message.reply("No negative values allowed!")
		if (isNaN(args[0])) return message.reply("Please give a numerical value!")
		try {
            client.distube.setVolume(message, args[0]); 
            const embed = new Discord.MessageEmbed()
			.setTitle(`\`🔊\` The volume is now \`${args[0]}%\``)
        	.setColor('5124e3')
        	.setAuthor(`${message.author.username}:`, message.author.avatarURL())
        	.setTimestamp()
    	return message.channel.send(embed)
    } catch (err) {
        console.log(err);
    }
}
}