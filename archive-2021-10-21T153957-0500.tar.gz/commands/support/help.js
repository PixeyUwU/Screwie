const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const fs = require('fs');

module.exports = {
  name: "help",
  aliases: ["h"],
  description: "Help Command!",
  usage: "Help | <Command Name>",
     async execute (message, args) {
    const client = message.client;
         
    let musiccmds = Array.from(fs.readdirSync('commands/music').filter(file => file.endsWith('.js')).map(a => a.replace(".js", "")));
    let supportcmds = Array.from(fs.readdirSync('commands/support').filter(file => file.endsWith('.js')).map(a => a.replace(".js", "")));
    let premiumcmds = Array.from(fs.readdirSync('commands/premium').filter(file => file.endsWith('.js')).map(a => a.replace(".js", "")));
    let oocmds = Array.from(fs.readdirSync('commands/ownersonly').filter(file => file.endsWith('.js')).map(a => a.replace(".js", "")));
    let embed = new MessageEmbed()
    	.setTitle(`${client.user.username} Commands!`)
    	.setDescription(`Use \`-help <command name>\` for more info about a command!`)
    	.addFields(
        	{ name: "Music", value: `\`\`\`\n${musiccmds.join("\n")}\n\`\`\``, inline: false },
            { name: "Support", value: `\`\`\`\n${supportcmds.join("\n")}\n\`\`\``, inline: false },
            { name: "Premium", value: `\`\`\`\n${premiumcmds.join("\n")}\n\`\`\``, inline: false },
            { name: "Owners Only", value: `\`\`\`\n${oocmds.join("\n")}\n\`\`\``, inline: false },
        )
    	.setFooter(`Requested By ${message.author.username}`)
    	.setAuthor(message.author.username, message.author.avatarURL())
    	.setColor("PINK")
    	.setTimestamp();

    
    if (!args.length) return message.channel.send(embed);

    let cmd =
      client.commands.get(args[0].toLowerCase()) ||
      client.commands.get(client.aliases.get(args[0].toLowerCase()));

    let embed2 = new MessageEmbed()
      .setTitle(`${cmd.name} Information!`)
      .addField(`Aliases`, cmd.aliases || "None!")
      .addField(`Usage`, cmd.usage || "No Usage")
      .addField(`Description`, cmd.description || "No Description!")
      .setTimestamp();

    if (cmd) {
      return message.channel.send(embed2);
    } else {
      return message.channel.send(embed);
    }
  }
};
